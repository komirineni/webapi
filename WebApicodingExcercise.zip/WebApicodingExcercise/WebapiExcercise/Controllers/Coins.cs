﻿namespace WebapiExcercise.Controllers
{
    public class Coins
    {
        public string id { get; set; }
        public string symbol { get; set; }
        public string name { get; set; }

    }
}