﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace WebapiExcercise.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {

            IEnumerable<Coins> listcoins = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:4834/api/");
                //HTTP GET
                var responseTask = client.GetAsync("Coins");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Coins>>();
                    readTask.Wait();

                    listcoins = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    listcoins = Enumerable.Empty<Coins>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(listcoins);
        }
    }
}
