﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
namespace WebapiExcercise.Controllers
{
    public class CoinsController : ApiController
    {
        // GET: api/Coins
        [HttpGet,Route("api/Coins")]
        public IEnumerable<Coins> Get()
        {
            string uri = @"https://api.coingecko.com/api/v3/coins/list";
            HttpClient client = new HttpClient();
            var resp = client.GetAsync(uri).Result.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<IEnumerable<Coins>>(resp);
            return result;
        }

        // GET: api/Coins/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Coins
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Coins/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Coins/5
        public void Delete(int id)
        {
        }
    }
}
